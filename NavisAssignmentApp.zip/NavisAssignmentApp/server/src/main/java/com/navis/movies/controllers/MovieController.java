package com.navis.movies.controllers;

import com.navis.movies.dto.GenreDTO;
import com.navis.movies.dto.MovieResultDTO;
import com.navis.movies.dto.SingleMovie;

import com.navis.movies.exception.MovieNotFoundException;
import com.navis.movies.service.MovieService;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static com.navis.movies.Application.MOVIE_URL;

@RestController
@RequestMapping(MOVIE_URL)
public class MovieController {


	@Autowired
	MovieService movieService;

	@Operation(description = "Get featured Movies")
	@GetMapping("/featured")
	public List<MovieResultDTO> getFeaturedMovies()  {
		return movieService.getFeaturedMovies();
	}
	
	@Operation(description = "Get Genres")
	@GetMapping("/genres")
	public List<GenreDTO> getGenreList(){
		return movieService.getGenreList();

	}
	
	@Operation(description = "Get Movies by title/actor/genre")
	@GetMapping("/searchresults")
	public Page<MovieResultDTO> getMovieBasedOnSearch(@RequestParam Optional<String> title, @RequestParam Optional<String> actor, @RequestParam Optional<String> genre,
			Optional<Integer> offset)
	{ 
		Page<MovieResultDTO> page = movieService.getMovieBasedOnSearch(title, actor, genre,offset);
		if(!page.hasContent())
			throw new MovieNotFoundException("movie not found exception");
		else
			return page;
		 
	}

	@Operation(description = "Get Movies by id")
	@GetMapping("/{id}")
	public SingleMovie findMovieByID(@PathVariable("id") Integer id)
	{
		SingleMovie singleMovie = movieService.findMovieByID(id);
		if(singleMovie==null)
			throw new MovieNotFoundException("movie not found exception");
		else
			return singleMovie;
	}
} 




