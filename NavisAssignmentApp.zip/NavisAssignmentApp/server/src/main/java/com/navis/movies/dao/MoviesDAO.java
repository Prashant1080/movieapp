package com.navis.movies.dao;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.navis.movies.dto.GenreDTO;
import com.navis.movies.dto.MovieDTO;
import com.navis.movies.dto.MovieResultDTO;



@Repository
public class MoviesDAO {


	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<MovieResultDTO> getFeaturedMovies()
	{
		final List<MovieResultDTO> movies = jdbcTemplate.query(
				"SELECT m.id, m.title, m.year, m.rating, m.poster, f.sort from movies m inner join featured_movies f on f.movie_id = m.id order by sort"
				, (rs, rowNum) -> { MovieResultDTO dto = new MovieResultDTO();
				dto.setId(rs.getInt("id")); dto.setTitle(rs.getString("title"));
				dto.setYear(rs.getString("year")); dto.setRating(rs.getString("rating"));
				dto.setPoster(rs.getString("poster")); dto.setSort(Optional.of(rs.getInt("sort"))); return
						dto; } );  return movies;
	}

	//search by title
	public List<MovieResultDTO> getMoviesByTitle(Optional<String> value) {
		final List<MovieResultDTO> movieList = jdbcTemplate.query("SELECT m.id, m.title, m.year, m.rating, m.poster, m.studio,m.plot from movies m where m.title like'%"+value.orElse("_")+"%'" , (rs, rowNum) -> { MovieResultDTO dto = new MovieResultDTO();
		dto.setId(rs.getInt("id")); dto.setTitle(rs.getString("title"));
		dto.setYear(rs.getString("year")); dto.setRating(rs.getString("rating"));
		dto.setPoster(rs.getString("poster")); dto.setSort(Optional.empty()); return
				dto; } ); 
		return movieList;

	}

	//search by actor
	public List<MovieResultDTO> getMoviesByActor(Optional<String> value)
	{
		final List<MovieResultDTO> movieList = jdbcTemplate.query("SELECT m.id, m.title, m.year, m.rating, m.poster, m.studio,m.plot from movies m inner join movie_to_actor mt on m.id = mt.movie_id "
				+ "inner join actors a on a.id = mt.actor_id where a.name like'%"+value.orElse("_")+"%' order by m.ID" , (rs, rowNum) -> { MovieResultDTO dto = new MovieResultDTO();
		dto.setId(rs.getInt("id")); dto.setTitle(rs.getString("title"));
		dto.setYear(rs.getString("year")); dto.setRating(rs.getString("rating"));
		dto.setPoster(rs.getString("poster")); dto.setSort(Optional.empty()); return
				dto; } ); return movieList;
	}

	//search by genre
	public List<MovieResultDTO> getMoviesByGenre(Optional<String> value){
		final List<MovieResultDTO> movieList = jdbcTemplate.query("SELECT m.id, m.title, m.year, m.rating, m.poster, m.studio,m.plot from movies m inner join movie_to_genre mg on m.id = mg.movie_id "
				+ "inner join genres g on g.id = mg.genre_id where g.description ='"+value.orElse("_")+"' order by m.ID" , (rs, rowNum) -> { MovieResultDTO dto = new MovieResultDTO();
		dto.setId(rs.getInt("id")); dto.setTitle(rs.getString("title"));
		dto.setYear(rs.getString("year")); dto.setRating(rs.getString("rating"));
		dto.setPoster(rs.getString("poster")); dto.setSort(Optional.empty()); return
				dto; } ); return movieList;
	}

	//find by move_id
	public List<MovieDTO> findMovieByID(int movie_id)
	{
		final List<MovieDTO> movie = jdbcTemplate.query("SELECT m.id, m.title,m.rating, m.year, m.poster, m.studio,m.plot,g.description,a.name from movies m "
				+ "inner join movie_to_actor mt on m.id = mt.movie_id inner join actors a on a.id = mt.actor_id "
				+ "inner join movie_to_genre mg on mg.movie_id = m.id inner join genres g on g.id = mg.genre_id "
				+ "where m.id ="+ movie_id  , (rs, rowNum) -> { MovieDTO dto = new MovieDTO();
		dto.setId(rs.getInt("id")); 
		dto.setTitle(rs.getString("title"));
		dto.setYear(rs.getString("year")); 
		dto.setPoster(rs.getString("poster")); 
		dto.setPlot(rs.getString("plot"));
		dto.setStudio(rs.getString("studio"));
		dto.setActor(rs.getString("name"));
		dto.setRating(rs.getString("rating"));
		dto.setDescription(rs.getString("description"));
		return dto; 
		}); 

		return movie;
	}
	
	public List<GenreDTO> getGenreList()
	{
		final List<GenreDTO> genreList = jdbcTemplate.query("Select * from genres", (rs, rowNum) -> { GenreDTO dto = new GenreDTO();
		dto.setId(rs.getInt("id")); dto.setGenreDescripton(rs.getString("description")); return
				dto; } );  return genreList; 
	}

}
