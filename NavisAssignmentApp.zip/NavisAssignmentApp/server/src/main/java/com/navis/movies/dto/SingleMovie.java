package com.navis.movies.dto;

import java.util.HashSet;
import java.util.Set;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class SingleMovie {
	private int id;
    private String title;
    private String year;
    private String plot;
    private String Studio;
    private String poster;
    private String rating;
    private Set<String> actor = new HashSet<>();
    private Set<String> description = new HashSet<>();
}
