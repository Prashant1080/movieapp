package com.navis.movies.exception;

public class MovieNotFoundException extends RuntimeException{

	public MovieNotFoundException() {
		super();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MovieNotFoundException(String message) {
		super(message);

	}


}
