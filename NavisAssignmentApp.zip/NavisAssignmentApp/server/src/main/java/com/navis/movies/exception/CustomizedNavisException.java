package com.navis.movies.exception;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomizedNavisException extends ResponseEntityExceptionHandler{

	@ExceptionHandler(MovieNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleMovieNotFoundException(MovieNotFoundException ex, WebRequest request){
		ExceptionResponse exceptionResponse =  new ExceptionResponse(new Date(), ex.getMessage());
		return new ResponseEntity<ExceptionResponse>(exceptionResponse,HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ExceptionResponse> handleAllException(Exception ex, WebRequest request){
		ExceptionResponse exceptionResponse =  new ExceptionResponse(new Date(), ex.getMessage());
		return new ResponseEntity<ExceptionResponse>(exceptionResponse,HttpStatus.BAD_REQUEST);

	}

}
