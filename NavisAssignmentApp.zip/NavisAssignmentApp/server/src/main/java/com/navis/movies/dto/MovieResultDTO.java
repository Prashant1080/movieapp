package com.navis.movies.dto;

import java.util.Optional;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@Setter
public class MovieResultDTO {
    private int id;
    private String title;
    private String year;
    private String rating;
    private Optional<Integer> sort= Optional.empty();
    private String poster;
    
}
