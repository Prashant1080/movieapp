package com.navis.movies.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.navis.movies.dao.MoviesDAO;
import com.navis.movies.dto.GenreDTO;
import com.navis.movies.dto.MovieDTO;
import com.navis.movies.dto.MovieResultDTO;
import com.navis.movies.dto.SingleMovie;

@Service
public class MovieService {

	@Autowired
	MoviesDAO moviesDao;

	public List<MovieResultDTO> getFeaturedMovies(){
		return moviesDao.getFeaturedMovies();

	}
	
	public List<GenreDTO> getGenreList(){
		return moviesDao.getGenreList();

	}

	public Page<MovieResultDTO> getMovieBasedOnSearch(Optional<String> title, Optional<String> actor, Optional<String> genre,Optional<Integer> offset)

	{           
		
		       Pageable p = PageRequest.of(offset.orElse(0), 6);
		        
				Set<MovieResultDTO> expectedResult = new HashSet<>();
				int titleCount = 0;
				int actorCount = 0;
				int genreCount = 0;
				int totalParamCount = 0;
				List<MovieResultDTO> titleResults = new ArrayList<>();
				List<MovieResultDTO> actorResults = new ArrayList<>();
				List<MovieResultDTO> genreResults = new ArrayList<>();
		
				if(title.isPresent() && title.get()!="")
				{	
					titleResults = moviesDao.getMoviesByTitle(title);
					titleCount = 1;
					totalParamCount++;
				}	
				if(actor.isPresent() && actor.get()!="")
				{	
					actorResults = moviesDao.getMoviesByActor(actor);
					actorCount = 1;
					totalParamCount++;
				}	
				if(genre.isPresent() && genre.get()!="")
				{	
					genreResults = moviesDao.getMoviesByGenre(genre);
					genreCount = 1;
					totalParamCount++;
				}
		
				switch(totalParamCount) 
				{
				case 0:
					expectedResult.clear();
					break;
				case 1:
					if (titleCount == 1)
					{
						for(MovieResultDTO movie: titleResults)
							expectedResult.add(movie);
					}
					else if(actorCount == 1)
					{	
						for(MovieResultDTO movie: actorResults)
							expectedResult.add(movie);
					}
					else
					{  
						for(MovieResultDTO movie: genreResults)
							expectedResult.add(movie);
					}
					break;
				case 2:
					expectedResult.clear();
					if(titleCount == 1 && actorCount == 1)
					{
						for(int i=0;i<titleResults.size();i++)
						{
							int id = titleResults.get(i).getId();
							for(int j=0; j<actorResults.size();j++) {
								if(id == actorResults.get(j).getId())
									if(!expectedResult.contains(titleResults.get(i)))
										expectedResult.add(titleResults.get(i));
							}
		
						}
		
					}
		
					else if(titleCount == 1 && genreCount == 1)
					{
						for(int i=0;i<titleResults.size();i++)
						{
							int id = titleResults.get(i).getId();
							for(int j=0; j<genreResults.size();j++) {
								if(id == genreResults.get(j).getId())
									if(!expectedResult.contains(titleResults.get(i)))
										expectedResult.add(titleResults.get(i));
							}
		
						}
		
					}
		
					else
					{
						for(int i=0;i<genreResults.size();i++)
						{
							int id = genreResults.get(i).getId();
							for(int j=0; j<actorResults.size();j++) {
								if(id == actorResults.get(j).getId())
									if(!expectedResult.contains(genreResults.get(i)))
										expectedResult.add(genreResults.get(i));
							}
		
						}
					}
					break;
				case 3:
					for(int i=0; i<titleResults.size();i++)
					{
						for(int j=0; j<actorResults.size();j++) 
						{
							for(int k=0;k<genreResults.size();k++)
							{
								if((titleResults.get(i).getId() == actorResults.get(j).getId()) && (titleResults.get(i).getId() == genreResults.get(k).getId()))
									if(!expectedResult.contains(titleResults.get(i)))
										expectedResult.add(titleResults.get(i));  
							}
						}
					}
					break;  
				}
	      List<MovieResultDTO> movies = expectedResult.stream().collect(Collectors.toList());			
		  int size = expectedResult.stream().collect(Collectors.toList()).size();
		  long l = (long)size;
		  int start = offset.orElse(0);
		  int quotient = movies.size()/6;
		  if(start<quotient+1) {
			  start = start*6;
		  int end = (start + p.getPageSize()) > movies.size() ? movies.size() : (start + 6); 
		  return new PageImpl<MovieResultDTO>(movies.subList(start, end),p,l); }
		  else
		  {
			  movies.clear();
			  return new PageImpl<MovieResultDTO>(movies);
		  }	  
	}


	public SingleMovie findMovieByID(int movie_id)
	{
		Set<String> actor = new HashSet<>();
		Set<String> description = new HashSet<>();

		List<MovieDTO> findMovieByID = moviesDao.findMovieByID(movie_id);
		findMovieByID.stream().forEach(movie->
		{
			String act = movie.getActor();
			String desc = movie.getDescription();
			if(!actor.contains(act))
				actor.add(act);

			if(!description.contains(desc))
				description.add(desc);
		});

		SingleMovie singleMovie = new SingleMovie();
		singleMovie.setId(findMovieByID.get(0).getId());
		singleMovie.setTitle(findMovieByID.get(0).getTitle());
		singleMovie.setYear(findMovieByID.get(0).getYear());
		singleMovie.setPlot(findMovieByID.get(0).getPlot());
		singleMovie.setStudio(findMovieByID.get(0).getStudio());
		singleMovie.setPoster(findMovieByID.get(0).getPoster());
		singleMovie.setActor(actor);
		singleMovie.setDescription(description);
		singleMovie.setRating(findMovieByID.get(0).getRating());
		return singleMovie;
	}

}
