import { createSelector } from 'reselect';

const app = state => state.app;
const genre = state => state.genre;
const movie = state =>state.movie;
const searchedMovie = state =>state.searchedMovie;
export const selectFeaturedMovies = createSelector(app, app => app.featuredMovies);
export const selectGenres = createSelector(genre, genre => genre.genres);
export const selectMovieInfo = createSelector(movie, movie => movie.movieInfo);
export const selectSearchedMovie = createSelector(searchedMovie, search=> search.searchMovies.content);
