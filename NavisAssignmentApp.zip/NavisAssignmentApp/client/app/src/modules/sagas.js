import { all, takeLatest, put } from 'redux-saga/effects';
import * as Actions from '@app/modules/actions';
import buildAction from '@app/util/buildAction';
import axios from 'axios';

function* fetchFeaturedMovies(action) {
  const response = yield axios.get('/api/movie/featured');
  yield put(buildAction(Actions.SET_FEATURED_MOVIES, response.data));
}

function* fetchGenres(action) {
  const response = yield axios.get('/api/movie/genres');
  yield put(buildAction(Actions.SET_GENRES, response.data));
}

function* fetchMovieInfo(action) {
  const response = yield axios.get('/api/movie/'+action.payload);
  yield put(buildAction(Actions.SET_MOVIE_INFO, response.data));
}

function* fetchSearchMovie(action) {
  try{
  const response = yield axios.get('/api/movie/searchresults?title='+action.payload.title+'&actor='+action.payload.actor+'&genre='+action.payload.genre+'&offset='+action.payload.offset);
  yield put(buildAction(Actions.SET_SEARCHED_MOVIES, response.data));
  }
  catch(error){
    yield put(buildAction(Actions.SET_MOVIE_RESULTS," Oops! search is not valid"));
  }
}


export default function* watchAll() {
  yield all([
    takeLatest(Actions.FETCH_FEATURED_MOVIES, fetchFeaturedMovies),
    takeLatest(Actions.FETCH_GENRES, fetchGenres),
    takeLatest(Actions.FETCH_MOVIE_INFO,fetchMovieInfo),
    takeLatest(Actions.FETCH_SEARCHED_MOVIES,fetchSearchMovie),
  ]);
}

