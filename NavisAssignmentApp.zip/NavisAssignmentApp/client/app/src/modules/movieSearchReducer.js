import { handleActions } from 'redux-actions';
import * as Actions from './actions';

const initialState = {
  searchMovies: {content:[]},
  totalPages:null,
  error:null
};

const movieSearchReducer = handleActions(
  {
    [Actions.SET_SEARCHED_MOVIES]: (state, action) => {
      state.searchMovies = action?.payload;
      state.totalPages = action?.payload.totalPages;
      return state;
    },
    [Actions.SET_MOVIE_RESULTS]:(state , action)=>{
      state.error = action?.payload;
      return state;
    }
  },
  initialState
);

export default movieSearchReducer;