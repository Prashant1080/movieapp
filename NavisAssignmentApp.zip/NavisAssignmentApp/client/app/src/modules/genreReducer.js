
import { handleActions } from 'redux-actions';
import * as Actions from './actions';
const initialState = {
    genres: [],
  };

  const genreReducer = handleActions(
    {
      [Actions.SET_GENRES]: (state, action) => {
        state.genres = action?.payload;
        return state;
      },
    },
    initialState
  );
  
  export default genreReducer;