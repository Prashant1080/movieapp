const prefix = 'APP';

export const FETCH_FEATURED_MOVIES = `${prefix}.FETCH_FEATURED_MOVIES`;
export const SET_FEATURED_MOVIES = `${prefix}.SET_FEATURED_MOVIES`;
export const FETCH_GENRES = `${prefix}.FETCH_GENRES`;
export const SET_GENRES = `${prefix}.SET_GENRES`;
export const FETCH_MOVIE_INFO = `${prefix}.FETCH_MOVIE_INFO`;
export const SET_MOVIE_INFO = `${prefix}.SET_MOVIE_INFO`;
export const FETCH_SEARCHED_MOVIES = `${prefix}.FETCH_SEARCHED_MOVIES`;
export const SET_SEARCHED_MOVIES = `${prefix}.SET_SEARCHED_MOVIES`;
export const SET_MOVIE_RESULTS = `${prefix}.SET_MOVIE_RESULTS`;