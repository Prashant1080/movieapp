import { handleActions } from 'redux-actions';
import * as Actions from './actions';

const initialState = {
  movieInfo: {},
};

const movieinfoReducer = handleActions(
  {
    [Actions.SET_MOVIE_INFO]: (state, action) => {
      state.movieInfo = action?.payload;
      return state;
    },
  },
  initialState
);

export default movieinfoReducer;
