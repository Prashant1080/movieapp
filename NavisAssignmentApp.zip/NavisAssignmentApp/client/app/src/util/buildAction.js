export default (type, payload) => {
  return {
    type,
    payload,
  };
};
