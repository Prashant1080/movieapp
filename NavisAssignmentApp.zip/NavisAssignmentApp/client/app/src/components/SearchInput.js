// libs
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import buildAction from '@app/util/buildAction';
import createBrowserHistory from 'history/createBrowserHistory'

// components
import {
  withStyles,
  TextField,
  Select,
  Button,
  MenuItem,
} from '@material-ui/core';
import { FETCH_GENRES, FETCH_SEARCHED_MOVIES, SET_MOVIE_RESULTS } from '../modules/actions';
import { selectGenres } from '../modules/selectors';
import { Link } from 'react-router-dom';

const styles = theme => ({
  root: {
    display: 'flex',
    flexFlow: 'row wrap',
  },
  input: {
    backgroundColor: theme.palette.app.white,
    marginRight: 8,
    width:'150px',
    borderRadius:'4px',
    padding: '2px 0 0 9px'
  },
  
  searchButton: {
    width:'3.5rem',
    backgroundColor: theme.palette.app.yellow,
    fontWeight: '400',  
    borderRadius:'3px',
    textAlign:'center',
    padding:'5px',
    color:'#000000',
    textDecoration:'none'
  },
  inputLabel: {
    color: '#ABABAB',
  },
  
});

const SearchInput = props => {
  const { classes } = props;
  const history = createBrowserHistory();
  const [movieTitle,setMovieTitle] = React.useState("");
  const [movieActor,setMovieActor] = React.useState("");
  const [movieGenre,setMovieGenre] = React.useState("");
  const dispatch = useDispatch();

  const SearchHandler = ()=>{
    dispatch(buildAction(SET_MOVIE_RESULTS,null));
    dispatch(buildAction(FETCH_SEARCHED_MOVIES,{ title: movieTitle, genre: movieGenre, actor: movieActor,offset:0}));
    setMovieActor("");
    setMovieGenre("");
    setMovieTitle("")
  }
  


  useEffect(() => {
    dispatch(buildAction(FETCH_GENRES));
  }, []);

  const genres = useSelector(selectGenres);
  
  return (
    <div className={classes.root}>
      <TextField 
        placeholder='Title'
        className={classes.input}
        InputProps={{ disableUnderline: true }}
        value = {movieTitle}
        onChange = {(e)=>{setMovieTitle(e.target.value)}}
      />

      <TextField
        placeholder='Actor'
        className={classes.input}
        InputProps={{ disableUnderline: true }}
        value = {movieActor}
        onChange = {(e)=>{setMovieActor(e.target.value)}}
      />

      <Select className={classes.input} value={movieGenre} onChange ={(e)=>{setMovieGenre(e.target.value)}}>
        {genres.map((genre, index) => (
          <MenuItem value={genre.genreDescripton} key = {index}>{genre.genreDescripton}
        </MenuItem>
        ))}
      </Select>

      <Link to={"/search?title="+movieTitle+"&actor="+movieActor+"&genre="+movieGenre} className={classes.searchButton} onClick={SearchHandler}>
        Search
      </Link>
    </div>
  );
};

export default withStyles(styles)(SearchInput);
