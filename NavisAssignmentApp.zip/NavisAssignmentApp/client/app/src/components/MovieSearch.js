// libs
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

// components
import { withStyles, Typography } from '@material-ui/core';
import MovieCard from '@app/components/MovieCard';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Pagination from '@material-ui/lab/Pagination';
// modules
import { FETCH_FEATURED_MOVIES } from '@app/modules/actions';
import { selectFeaturedMovies } from '@app/modules/selectors';

// util
import buildAction from '@app/util/buildAction';
import { FETCH_MOVIE_INFO, FETCH_SEARCHED_MOVIES } from '../modules/actions';
import { selectMovieInfo, selectSearchedMovie, } from '../modules/selectors';
import movieSearchReducer from '../modules/movieSearchReducer';


function rand() {
    return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
    const top = 50 + rand();
    const left = 50 + rand();

    return {
        top: `${top}%`,
        left: `${left}%`,
        transform: `translate(-${top}%, -${left}%)`,
    };
}

const useStyles = makeStyles((theme) => ({
    paper: {
        position: 'absolute',
        width: '950px',
        backgroundColor: '#1E2129',
        border: '2px solid #000',
        top: '50% !important',
        left: '43% !important',
        transform: 'translate(-50%, -43%) !important',
    },
    headPaper: {
        width: '100%',
        height: '30%',
        backgroundColor: '#F3CA45',
        position: 'fixed',
        zIndex: -1,
       

    },
    side_content: {

        float: 'left',
        width: '60%',
        marginTop: '3rem',
        

    },
    poster: {

        // top: '2rem',
        // left: '5rem',
        float: 'left',
        width: '35%',
        padding: '20px',

    },
    movieYear:{
        float: 'left',
        fontWeight: 'normal',
        width:'100%',
        paddingBottom: '30px'
    },
    movieTitle: {
        float: 'left',
        fontWeight: 'bold',
        width:'100%',
        marginTop: '40px',
    },
    moviePlot: {
        fontFamily: 'Arial, Helvetica, sans-serif',
        color:'white'
    },
    movieActor: {
        fontStyle: 'oblique',
        color:'white'
    },
    movieGenre: {
        fontStretch: 'ultra-expanded',
        color:'white'
    },
    errormsg: {

    }
}));



const styles = theme => ({
    root: {
        // TODO
    },
});

const MovieSearch = props => {
    const { classes, large = false } = props;
    const dispatch = useDispatch();
    const [modalStyle] = React.useState(getModalStyle);
    const [open, setOpen] = React.useState(false);
    const movieStyle = useStyles();

    const width = large ? 267 : 200;
    const height = large ? 396 : 295;

    const handleOpen = (value) => {
        setOpen(value);
    };

    const handleMovieID = (id) => {
        dispatch(buildAction(FETCH_MOVIE_INFO, id));
    }
    const handleClose = () => {
        setOpen(false);
    };

    const movieGenre = new URLSearchParams(window.location.search).get('genre');
    const movieTitle = new URLSearchParams(window.location.search).get('title');
    const movieActor = new URLSearchParams(window.location.search).get('actor');


    useEffect(() => {
        dispatch(buildAction(FETCH_SEARCHED_MOVIES, { title: movieTitle, actor: movieActor, genre: movieGenre, offset: page }));
    }, []);

    const movies = useSelector(selectSearchedMovie);
    const movie = useSelector(selectMovieInfo);
    const { movieInfo } = movie;
    const pageState = useSelector(state => state.searchedMovie);
    const { totalPages } = pageState;
    console.log(totalPages);
    const errorState = useSelector(state => state.searchedMovie);
    const { error } = errorState;
    const [page, setPage] = React.useState(0);
    const handleChange = (event, value) => {
        setPage(value);
        dispatch(buildAction(FETCH_SEARCHED_MOVIES, { title: movieTitle, actor: movieActor, genre: movieGenre, offset: page }));
    };

    const body = (
        <div style={modalStyle} className={movieStyle.paper}>
            <div className={movieStyle.headPaper}>
               
              
            </div>
            <div className={classes.clickable}>
                <div className={movieStyle.poster}> <img
                    src={`/images/${movie.poster}`}
                    alt={`${movie.title} Poster`}
                     />
                </div>
                <div className={movieStyle.side_content}>
                <Typography className={movieStyle.movieTitle}>
                    {movie.title}
                </Typography>    
                       <Typography className={movieStyle.movieYear}>
                        {movie.year} ({movie.rating})
                    </Typography>
                    <Typography className={movieStyle.moviePlot}>
                        {movie.studio}
                    </Typography>
                    <Typography className={movieStyle.moviePlot}>
                        {movie.plot}
                    </Typography>
                    <div className={movieStyle.moviePlot}>Starring</div>
                    <Typography className={movieStyle.movieActor}>
                        {movie.actor}
                    </Typography>
                    <Typography className={movieStyle.movieGenre}>
                        {movie.description}
                    </Typography>
                </div>
            </div>
        </div>
    );

    return (
        <div className={classes.root}>
            {error ? <div><h1 style={{ color: 'white' }}>{error}</h1></div> : movies.map((movie, index) => (
                <MovieCard large data={movie} MovieId={handleMovieID} OpenModal={handleOpen} key={index} />
            ))

            }

            <div>
                <Modal
                    open={open}
                    onClose={handleClose}
                >
                    {body}
                </Modal>
            </div>

            <Pagination count={totalPages} shape="rounded" page={page} onChange={handleChange} />
        </div>

    );
};

export default withStyles(styles)(MovieSearch);
