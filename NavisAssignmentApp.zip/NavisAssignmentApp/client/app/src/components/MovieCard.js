// libs
import React from 'react';

// components
import { withStyles, Typography } from '@material-ui/core';

// modules
import { SET_SELECTED_MOVIE_ID } from '@app/modules/actions';

// util
import buildAction from '@app/util/buildAction';
import { Link } from 'react-router-dom';

const styles = theme => ({
  root: {
    padding: '30px 20px 0px',
    float:'left',
    '& .MuiTypography-root': {
      color: theme.palette.app.white,
    },
  },
  clickable: {
    cursor: 'pointer',
    
  },
  poster: {
    borderRadius: '4px',
    webkitBoxShadow: "0 0 3px #000",
    mozBoxShadow: "0 0 3px #000",
    boxShadow: "0 0 3px #000",
  },
  title: {
    fontWeight: '600'
  },
});

const MovieCard = props => {
  const { data, large = false, classes } = props;

  const width = large ? 267 : 200;
  const height = large ? 396 : 295;

 const handleModal= ()=>{
     props.OpenModal(true);
     handleMovieID()
  }

  const handleMovieID =()=>{
    props.MovieId(data.id)
  }

  return (
    <div className={classes.root} style={{ width }}>
      <a onClick={handleModal}>
      <div className={classes.clickable}>
        <img
          src={`/images/${data.poster}`}
          alt={`${data.title} Poster`}
          className={classes.poster}
          style={{ width, height }}
        />
        <Typography className={classes.title}>
          {data.title}
        </Typography>
        <Typography>
          {data.year} ({data.rating})
        </Typography>
      </div>
      </a>
    </div>
  );
};

export default withStyles(styles)(MovieCard);
