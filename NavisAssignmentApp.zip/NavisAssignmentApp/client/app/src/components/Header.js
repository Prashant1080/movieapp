// libs
import React from 'react';

// components
import { withStyles } from '@material-ui/core';
import Logo from '@app/components/Logo';
import SearchInput from '@app/components/SearchInput';

const styles = theme => ({
  root: {
    backgroundColor: theme.palette.app.darkGray,
    // TODO
  },
  left: {
    float:'left',
    padding: '20px 0px 10px 0px',
  },
  right:{
    float:'right',
    padding: '25px 57px 20px 0px',
  },
  wrapper:{
    margin: '0 auto',
    width: '960px',
    backgroundColor: theme.palette.app.darkGray,
    borderRadius: '4px 4px 0 0',
    padding: '0 20px',
    webkitBoxShadow: "0 0 4px #000",
    mozBoxShadow: "0 0 4px #000",
    boxShadow: "0 0 4px #000"
  },
  clear : {
    clear: 'both',
  },
});

const Header = props => {
  const { classes } = props;

  return (
    <div >
      <div className={classes.wrapper}>
          <div className={classes.left}><Logo /></div>
          <div className={classes.right}><SearchInput /></div>
          <div className={classes.clear}></div>
     </div>
    </div>
  );
};

export default withStyles(styles)(Header);
