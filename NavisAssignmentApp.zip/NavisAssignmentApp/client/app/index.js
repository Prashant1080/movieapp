function init() {
  import(/* webpackChunkName: "app-src" */ './src/app');
}

init();
